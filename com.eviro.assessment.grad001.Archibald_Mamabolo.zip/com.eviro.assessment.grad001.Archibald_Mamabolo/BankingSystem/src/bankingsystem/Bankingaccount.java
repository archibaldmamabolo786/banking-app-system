/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingsystem;

/**
 *
 * @author Archie
 */
import java.util.Scanner;
public class Bankingaccount 
{
    int amount = 5000;
    public void initiate(){
        login lg = new login();
        try{
            lg.acceptInput();
            lg.verify();
        }catch(Exception e){
            try{
                lg.acceptInput();
                lg.verify();
            }catch(Exception f){
                
            }
        }
    }
}
