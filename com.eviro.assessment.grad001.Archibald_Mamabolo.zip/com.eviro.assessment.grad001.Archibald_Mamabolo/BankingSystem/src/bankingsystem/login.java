/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingsystem;

/**
 *
 * @author Archie
 */
import java.util.Scanner;
import java.io.*;
public class login 
{
    
    int accountNum = 0;
    int accountPswd = 0;
    int ac, pw;
    
    public void acceptInput(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Your Account Number: ");
        ac = sc.nextInt();
        System.out.print("Enter Your Password: ");
        pw = sc.nextInt();
    }
    
    public void verify(){
        if(ac == accountNum && pw == accountPswd){
            System.out.println("Bank account login Successfully !");
        }else{
            System.out.println("incorrect login credentials !");
        }
    }
    
}
