/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingsystem;

/**
 *
 * @author Archie
 */
import java.util.Scanner;
public class BankingSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception
    {
        // TODO code application logic here
        Bankingaccount ba = new Bankingaccount();
        ba.initiate();
        
        int balance = 100000, withdraw, deposit;
        
        
        Scanner sc = new Scanner(System.in);
        
        while(true)
        {
            System.out.println("Welcome to Enviro-Bank !!");
            System.out.println("*****************************************************");
            System.out.println("Choose 1 for Withdraw");
            System.out.println("Choose 2 for Deposit");
            System.out.println("Choose 3 for Check Balance");
            System.out.println("Choose 4 for Exit");
            System.out.println("*****************************************************");
            System.out.println("Choose the operation you want to perform");
            
            
            int choice = sc.nextInt();
            switch(choice)
            {
                case 1:
                    System.out.print("Enter money to be withdrawn:");
                    withdraw = sc.nextInt();
                    
                    if(balance == withdraw)
                    {
                        balance = balance - withdraw;
                        System.out.println("Please collect your money");
                    }
                    else
                    {
                        System.out.println("Insufficient Balance");
                        System.out.println("Would you like to apply for an ovedraft?");
                        System.out.println("1:Yes");
                        System.out.println("2:No:,Return me back to menu.");
                        choice = sc.nextInt();
                        //if(choice.equalsIgnoreCase("1")){
                            if(balance - withdraw - 5<= -20000){
                                System.out.println("You have exceeded your Overdraft Limit, you will nowbe returned to menus");
                            }else{//if not exceeding bank balance
                                balance -= withdraw + 5;
                                System.out.println("You have withdrawn R" + withdraw);
                                System.out.println("You now have a balance of R" + balance);
                            }
                        //}
                    }
                    System.out.println("");
                    break;
                    
                case 2:
                    System.out.print("Enter money to be deposited:");
                    deposit = sc.nextInt();
                    
                    balance = balance + deposit;
                    System.out.println("Your Money has been successfully deposited");
                    System.out.println("");
                    break;
                    
                case 3:
                    System.out.println("Balance: " + balance);
                    System.out.println("");
                    break;
                    
                case 4:
                    System.exit(0);
                    
            }
        }
    }
    
}
